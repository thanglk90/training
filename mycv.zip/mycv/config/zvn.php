<?php

return [

    'url' => [
        'prefix_admin' => 'admin'
    ]

];

?>